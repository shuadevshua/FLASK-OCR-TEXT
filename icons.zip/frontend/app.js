// ============================================
// TOXISCAN PRO - Professional SaaS Tool
// Complete Frontend Logic with New Layout
// ============================================

// API Configuration
const API_URL = 'http://localhost:5000/api/predict';
const OCR_API_URL = 'http://localhost:5000/api/ocr';
const OCR_PREDICT_API_URL = 'http://localhost:5000/api/ocr_predict';

// State Management
let currentTool = 'toxicity';
let currentText = '';
let analysisHistory = [];
let chart = null;

// Initialize App
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeApp);
} else {
    initializeApp();
}

// ============================================
// INITIALIZATION
// ============================================

function initializeApp() {
    try {
        setupSidebar();
        setupToolSwitching();
        setupToxicityChecker();
        setupOCR();
        setupDashboard();
        loadHistory();
        updateDashboard();
        
        console.log('✅ ToxiScan Pro initialized successfully');
    } catch (error) {
        console.error('❌ Error initializing ToxiScan Pro:', error);
        showToast('Application failed to initialize', 'error');
    }
}

// ============================================
// SIDEBAR & NAVIGATION
// ============================================

function setupSidebar() {
    const toggleBtn = document.getElementById('sidebar-toggle');
    const sidebar = document.querySelector('.sidebar');
    
    if (toggleBtn) {
        toggleBtn.addEventListener('click', () => {
            sidebar.classList.toggle('open');
        });
    }
}

function setupToolSwitching() {
    const navItems = document.querySelectorAll('.nav-item');
    
    navItems.forEach(item => {
        item.addEventListener('click', () => {
            const tool = item.dataset.tool;
            switchTool(tool);
            
            // Update active states
            navItems.forEach(nav => nav.classList.remove('active'));
            item.classList.add('active');
        });
    });
}

function switchTool(tool) {
    currentTool = tool;
    
    // Hide all views
    document.querySelectorAll('.tool-view').forEach(view => {
        view.classList.remove('active');
    });
    
    // Show selected view
    const view = document.getElementById(`${tool}-view`);
    if (view) {
        view.classList.add('active');
    }
    
    // Update dashboard when switching to it
    if (tool === 'dashboard') {
        updateDashboard();
    }
}

// ============================================
// TOXICITY CHECKER
// ============================================

function setupToxicityChecker() {
    const textEditor = document.getElementById('text-editor');
    const analyzeBtn = document.getElementById('analyze-btn');
    const clearBtn = document.getElementById('clear-btn');
    const exampleBtn = document.getElementById('example-btn');
    
    // Character & word count
    if (textEditor) {
        textEditor.addEventListener('input', updateTextStats);
        
        // Handle paste
        textEditor.addEventListener('paste', (e) => {
            e.preventDefault();
            const text = e.clipboardData.getData('text/plain');
            insertTextAtCursor(textEditor, text);
            updateTextStats();
        });
    }
    
    // Analyze button
    if (analyzeBtn) {
        analyzeBtn.addEventListener('click', handleAnalyze);
    }
    
    // Clear button
    if (clearBtn) {
        clearBtn.addEventListener('click', clearEditor);
    }
    
    // Example button
    if (exampleBtn) {
        exampleBtn.addEventListener('click', loadExample);
    }
}

function updateTextStats() {
    const textEditor = document.getElementById('text-editor');
    if (!textEditor) return;
    
    const text = textEditor.textContent.trim();
    const wordCount = text ? text.split(/\s+/).filter(w => w.length > 0).length : 0;
    const charCount = text.length;
    
    const wordCountEl = document.getElementById('word-count');
    const charCountEl = document.getElementById('char-count');
    
    if (wordCountEl) wordCountEl.textContent = `${wordCount} word${wordCount !== 1 ? 's' : ''}`;
    if (charCountEl) charCountEl.textContent = `${charCount} character${charCount !== 1 ? 's' : ''}`;
}

function insertTextAtCursor(element, text) {
    const selection = window.getSelection();
    if (selection.rangeCount > 0) {
        const range = selection.getRangeAt(0);
        range.deleteContents();
        range.insertNode(document.createTextNode(text));
        range.collapse(false);
        selection.removeAllRanges();
        selection.addRange(range);
    } else {
        element.textContent += text;
    }
}

function clearEditor() {
    const textEditor = document.getElementById('text-editor');
    if (textEditor) {
        textEditor.textContent = '';
        updateTextStats();
        resetToxicityResults();
    }
}

function loadExample() {
    const examples = [
        "This is a normal comment that should be safe.",
        "You're an idiot and I hate you!",
        "I think we should discuss this matter professionally.",
        "This product is terrible and you should feel bad for making it."
    ];
    
    const textEditor = document.getElementById('text-editor');
    if (textEditor) {
        const randomExample = examples[Math.floor(Math.random() * examples.length)];
        textEditor.textContent = randomExample;
        updateTextStats();
    }
}

async function handleAnalyze() {
    const textEditor = document.getElementById('text-editor');
    if (!textEditor) return;
    
    const text = textEditor.textContent.trim();
    
    if (!text) {
        showToast('Please enter some text to analyze', 'warning');
        return;
    }

    await analyzeText(text);
}

async function analyzeText(text) {
    const analyzeBtn = document.getElementById('analyze-btn');
    showLoading('Analyzing text...');
    
    if (analyzeBtn) {
        analyzeBtn.classList.add('loading');
    }

    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ comment: text })
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();

        if (data.error) {
            throw new Error(data.error);
        }
        
        // Store in history
        addToHistory(text, data);

        // Display results
        displayToxicityResults(data, text);

    } catch (error) {
        console.error('Analysis error:', error);
        showToast(`Error: ${error.message}`, 'error');
    } finally {
        hideLoading();
        if (analyzeBtn) {
            analyzeBtn.classList.remove('loading');
        }
    }
}

function displayToxicityResults(data, originalText) {
    const placeholder = document.querySelector('#toxicity-results .results-placeholder');
    const resultsContent = document.getElementById('toxicity-results-content');
    
    if (!placeholder || !resultsContent) return;
    
    // Hide placeholder, show results
    placeholder.classList.add('hidden');
    resultsContent.classList.remove('hidden');
    
    // Update overall score
    updateOverallScore(data);

    // Create chart
    setTimeout(() => {
        createChart(data.scores || {});
    }, 300);
    
    // Update categories
    updateCategories(data.scores || {});
    
    // Update issues
    updateIssues(data.scores || {});
}

function updateOverallScore(data) {
    const toxicScore = data.scores?.toxic || 0;
    const percentage = Math.round(toxicScore * 100);
    
    // Update badge
    const scoreBadge = document.getElementById('score-badge');
    if (scoreBadge) {
        let badgeText = 'Clean';
        let badgeClass = 'safe';
        
        if (data.rating) {
            badgeText = data.rating;
            if (data.severity === 'high' || badgeText.includes('Highly')) {
                badgeClass = 'toxic';
            } else if (data.severity === 'medium' || badgeText.includes('Mildly')) {
                badgeClass = 'warning';
            }
        } else {
            if (toxicScore >= 0.6) {
                badgeText = 'Highly Toxic';
                badgeClass = 'toxic';
            } else if (toxicScore >= 0.3) {
                badgeText = 'Mildly Toxic';
                badgeClass = 'warning';
            }
        }
        
        scoreBadge.textContent = badgeText;
        scoreBadge.className = `score-badge ${badgeClass}`;
    }
    
    // Update meter
    const meterFill = document.getElementById('meter-fill');
    const meterText = document.getElementById('meter-text');
    
    if (meterFill) {
        meterFill.style.width = `${percentage}%`;
        meterFill.className = `meter-fill ${data.severity === 'high' ? 'toxic' : data.severity === 'medium' ? 'warning' : ''}`;
    }
    
    if (meterText) {
        meterText.textContent = `${percentage}%`;
    }
}

function updateCategories(scores) {
    const categoriesList = document.getElementById('categories-list');
    if (!categoriesList || !scores) return;
    
    categoriesList.innerHTML = '';
    
    Object.entries(scores).forEach(([label, value]) => {
        const item = document.createElement('div');
        item.className = 'category-item';
        
        const labelEl = document.createElement('div');
        labelEl.className = 'category-label';
        labelEl.textContent = label.replace('_', ' ').toUpperCase();
        
        const valueEl = document.createElement('div');
        valueEl.className = 'category-value';
        const percentage = Math.round(value * 100);
        valueEl.textContent = `${percentage}%`;
        
        if (percentage >= 60) {
            valueEl.classList.add('high');
        } else if (percentage >= 30) {
            valueEl.classList.add('medium');
        } else {
            valueEl.classList.add('low');
        }
        
        item.appendChild(labelEl);
        item.appendChild(valueEl);
        categoriesList.appendChild(item);
    });
}

function updateIssues(scores) {
    const issuesList = document.getElementById('issues-list');
    if (!issuesList || !scores) return;
    
    issuesList.innerHTML = '';
    
    const highRiskCategories = Object.entries(scores)
        .filter(([label, value]) => value >= 0.3)
        .sort((a, b) => b[1] - a[1]);
    
    if (highRiskCategories.length === 0) {
        issuesList.innerHTML = '<div class="issue-item">✅ No toxic content detected. Your text appears to be clean!</div>';
        return;
    }
    
    highRiskCategories.forEach(([label, value]) => {
        const item = document.createElement('div');
        item.className = 'issue-item';
        const percentage = Math.round(value * 100);
        
        if (percentage >= 60) {
            item.classList.add('toxic');
        }
        
        item.textContent = `⚠️ ${label.replace('_', ' ').toUpperCase()}: ${percentage}% confidence`;
        issuesList.appendChild(item);
    });
}

function resetToxicityResults() {
    const placeholder = document.querySelector('#toxicity-results .results-placeholder');
    const resultsContent = document.getElementById('toxicity-results-content');
    
    if (placeholder) placeholder.classList.remove('hidden');
    if (resultsContent) resultsContent.classList.add('hidden');
    
    if (chart) {
        chart.destroy();
        chart = null;
    }
}

// ============================================
// CHART CREATION
// ============================================

function createChart(scores) {
    if (typeof Chart === 'undefined') {
        setTimeout(() => createChart(scores), 100);
        return;
    }
    
    const chartCanvas = document.getElementById('chart-canvas');
    if (!chartCanvas) return;
    
    const ctx = chartCanvas.getContext('2d');
    
    // Destroy existing chart
    if (chart) {
        chart.destroy();
    }
    
    if (!scores || Object.keys(scores).length === 0) return;

    const labels = Object.keys(scores);
    const values = Object.values(scores);

    chart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels.map(l => l.replace('_', ' ').toUpperCase()),
            datasets: [{
                label: 'Toxicity Score',
                data: values,
                backgroundColor: values.map(v => {
                    if (v >= 0.6) return 'rgba(239, 68, 68, 0.8)';
                    if (v >= 0.3) return 'rgba(251, 191, 36, 0.8)';
                    return 'rgba(46, 204, 113, 0.8)';
                }),
                borderColor: values.map(v => {
                    if (v >= 0.6) return '#EF4444';
                    if (v >= 0.3) return '#F59E0B';
                    return '#2ECC71';
                }),
                borderWidth: 2,
                borderRadius: 8,
                borderSkipped: false,
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    backgroundColor: 'rgba(255, 255, 255, 0.95)',
                    titleColor: '#1A1A1A',
                    bodyColor: '#6B7280',
                    borderColor: '#E5E7EB',
                    borderWidth: 1,
                    padding: 12,
                    cornerRadius: 8,
                    callbacks: {
                        label: function(context) {
                            return `Score: ${(context.parsed.y * 100).toFixed(1)}%`;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 1,
                    ticks: {
                        color: '#6B7280',
                        font: { size: 12 },
                        callback: function(value) {
                            return (value * 100).toFixed(0) + '%';
                        }
                    },
                    grid: {
                        color: 'rgba(0, 0, 0, 0.05)'
                    }
                },
                x: {
                    ticks: {
                        color: '#1A1A1A',
                        font: { size: 11, weight: '600' }
                    },
                    grid: {
                        display: false
                    }
                }
            },
            animation: {
                duration: 1200,
                easing: 'easeOutQuart'
            }
        }
    });
}

// ============================================
// OCR FUNCTIONALITY
// ============================================

function setupOCR() {
    const imageInput = document.getElementById('image-input');
    const uploadTrigger = document.getElementById('upload-trigger');
    const uploadArea = document.getElementById('ocr-upload-area');
    const removeBtn = document.getElementById('remove-image-btn');
    const extractBtn = document.getElementById('extract-btn');
    const analyzeExtractedBtn = document.getElementById('analyze-extracted-btn');
    const copyBtn = document.getElementById('copy-text-btn');
    
    // File input
    if (imageInput && uploadTrigger) {
        uploadTrigger.addEventListener('click', () => imageInput.click());
        imageInput.addEventListener('change', (e) => handleImageSelect(e));
    }
    
    // Drag and drop
    if (uploadArea) {
        uploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadArea.classList.add('drag-over');
        });
        
        uploadArea.addEventListener('dragleave', () => {
            uploadArea.classList.remove('drag-over');
        });
        
        uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadArea.classList.remove('drag-over');
            const file = e.dataTransfer.files[0];
            if (file && file.type.startsWith('image/')) {
                handleImageFile(file);
            }
        });
    }
    
    // Remove image
    if (removeBtn) {
        removeBtn.addEventListener('click', clearImage);
    }
    
    // Extract text
    if (extractBtn) {
        extractBtn.addEventListener('click', handleExtractText);
    }
    
    // Analyze extracted text
    if (analyzeExtractedBtn) {
        analyzeExtractedBtn.addEventListener('click', handleAnalyzeExtracted);
    }
    
    // Copy text
    if (copyBtn) {
        copyBtn.addEventListener('click', copyExtractedText);
    }
}

function handleImageSelect(e) {
    const file = e.target.files[0];
    if (file && file.type.startsWith('image/')) {
        handleImageFile(file);
    }
}

function handleImageFile(file) {
    if (file.size > 10 * 1024 * 1024) {
        showToast('Image size must be less than 10MB', 'error');
        return;
    }
    
    displayImagePreview(file);
    resetOCRResults();
    
    // Enable buttons
    const extractBtn = document.getElementById('extract-btn');
    const analyzeBtn = document.getElementById('analyze-extracted-btn');
    if (extractBtn) extractBtn.disabled = false;
    if (analyzeBtn) analyzeBtn.disabled = false;
}

function displayImagePreview(file) {
    const reader = new FileReader();
    const uploadContent = document.getElementById('upload-content');
    const previewContainer = document.getElementById('image-preview-container');
    const imagePreview = document.getElementById('image-preview');
    const imageInput = document.getElementById('image-input');
    
    reader.onload = (e) => {
        if (imagePreview) imagePreview.src = e.target.result;
        if (uploadContent) uploadContent.classList.add('hidden');
        if (previewContainer) previewContainer.classList.remove('hidden');
    };
    
    reader.readAsDataURL(file);
    
    // Store file for later use
    if (imageInput) {
        imageInput.dataset.file = JSON.stringify({ name: file.name, size: file.size });
    }
}

function clearImage() {
    const imageInput = document.getElementById('image-input');
    const uploadContent = document.getElementById('upload-content');
    const previewContainer = document.getElementById('image-preview-container');
    const extractBtn = document.getElementById('extract-btn');
    const analyzeBtn = document.getElementById('analyze-extracted-btn');
    
    if (imageInput) {
        imageInput.value = '';
        delete imageInput.dataset.file;
    }
    if (uploadContent) uploadContent.classList.remove('hidden');
    if (previewContainer) previewContainer.classList.add('hidden');
    if (extractBtn) extractBtn.disabled = true;
    if (analyzeBtn) analyzeBtn.disabled = true;
    
    resetOCRResults();
}

async function handleExtractText() {
    const imageInput = document.getElementById('image-input');
    if (!imageInput || !imageInput.files[0]) {
        showToast('Please select an image first', 'warning');
        return;
    }
    
    const extractBtn = document.getElementById('extract-btn');
    showLoading('Extracting text from image...');
    
    if (extractBtn) {
        extractBtn.classList.add('loading');
    }
    
    try {
        const formData = new FormData();
        formData.append('image', imageInput.files[0]);
        
        const response = await fetch(OCR_API_URL, {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.error) {
            throw new Error(data.error);
        }
        
        if (!data.text || data.message) {
            showToast(data.message || 'No text detected in the image', 'warning');
            return;
        }
        
        displayExtractedText(data.text);
        
    } catch (error) {
        console.error('OCR extraction error:', error);
        showToast(`Error: ${error.message}`, 'error');
    } finally {
        hideLoading();
        if (extractBtn) {
            extractBtn.classList.remove('loading');
        }
    }
}

async function handleAnalyzeExtracted() {
    const extractedText = document.getElementById('extracted-text-display')?.textContent.trim();
    
    if (!extractedText) {
        showToast('Please extract text from image first', 'warning');
        return;
    }
    
    await analyzeExtractedTextForOCR(extractedText);
}

async function analyzeExtractedTextForOCR(text) {
    const analyzeBtn = document.getElementById('analyze-extracted-btn');
    showLoading('Analyzing extracted text...');
    
    if (analyzeBtn) {
        analyzeBtn.classList.add('loading');
    }
    
    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ comment: text })
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.error) {
            throw new Error(data.error);
        }
        
        // Store in history
        addToHistory(text, data);
        
        // Display results in OCR panel
        displayOCRToxicityResults(data, text);
        
    } catch (error) {
        console.error('OCR Analysis error:', error);
        showToast(`Error: ${error.message}`, 'error');
    } finally {
        hideLoading();
        if (analyzeBtn) {
            analyzeBtn.classList.remove('loading');
        }
    }
}

function displayOCRToxicityResults(data, originalText) {
    const toxicitySection = document.getElementById('ocr-toxicity-section');
    if (!toxicitySection) return;
    
    // Show toxicity section
    toxicitySection.classList.remove('hidden');
    
    // Update overall score
    updateOCROverallScore(data);
    
    // Create chart
    setTimeout(() => {
        createOCRChart(data.scores || {});
    }, 300);
    
    // Update categories
    updateOCRCategories(data.scores || {});
    
    // Update issues
    updateOCRIssues(data.scores || {});
}

function updateOCROverallScore(data) {
    const toxicScore = data.scores?.toxic || 0;
    const percentage = Math.round(toxicScore * 100);
    
    // Update badge
    const scoreBadge = document.getElementById('ocr-score-badge');
    if (scoreBadge) {
        let badgeText = 'Clean';
        let badgeClass = 'safe';
        
        if (data.rating) {
            badgeText = data.rating;
            if (data.severity === 'high' || badgeText.includes('Highly')) {
                badgeClass = 'toxic';
            } else if (data.severity === 'medium' || badgeText.includes('Mildly')) {
                badgeClass = 'warning';
            }
        } else {
            if (toxicScore >= 0.6) {
                badgeText = 'Highly Toxic';
                badgeClass = 'toxic';
            } else if (toxicScore >= 0.3) {
                badgeText = 'Mildly Toxic';
                badgeClass = 'warning';
            }
        }
        
        scoreBadge.textContent = badgeText;
        scoreBadge.className = `score-badge ${badgeClass}`;
    }
    
    // Update meter
    const meterFill = document.getElementById('ocr-meter-fill');
    const meterText = document.getElementById('ocr-meter-text');
    
    if (meterFill) {
        meterFill.style.width = `${percentage}%`;
        meterFill.className = `meter-fill ${data.severity === 'high' ? 'toxic' : data.severity === 'medium' ? 'warning' : ''}`;
    }
    
    if (meterText) {
        meterText.textContent = `${percentage}%`;
    }
}

function updateOCRCategories(scores) {
    const categoriesList = document.getElementById('ocr-categories-list');
    if (!categoriesList || !scores) return;
    
    categoriesList.innerHTML = '';

    Object.entries(scores).forEach(([label, value]) => {
        const item = document.createElement('div');
        item.className = 'category-item';
        
        const labelEl = document.createElement('div');
        labelEl.className = 'category-label';
        labelEl.textContent = label.replace('_', ' ').toUpperCase();
        
        const valueEl = document.createElement('div');
        valueEl.className = 'category-value';
        const percentage = Math.round(value * 100);
        valueEl.textContent = `${percentage}%`;
        
        if (percentage >= 60) {
            valueEl.classList.add('high');
        } else if (percentage >= 30) {
            valueEl.classList.add('medium');
        } else {
            valueEl.classList.add('low');
        }
        
        item.appendChild(labelEl);
        item.appendChild(valueEl);
        categoriesList.appendChild(item);
    });
}

function updateOCRIssues(scores) {
    const issuesList = document.getElementById('ocr-issues-list');
    if (!issuesList || !scores) return;
    
    issuesList.innerHTML = '';
    
    const highRiskCategories = Object.entries(scores)
        .filter(([label, value]) => value >= 0.3)
        .sort((a, b) => b[1] - a[1]);
    
    if (highRiskCategories.length === 0) {
        issuesList.innerHTML = '<div class="issue-item">✅ No toxic content detected. Your text appears to be clean!</div>';
        return;
    }
    
    highRiskCategories.forEach(([label, value]) => {
        const item = document.createElement('div');
        item.className = 'issue-item';
        const percentage = Math.round(value * 100);
        
        if (percentage >= 60) {
            item.classList.add('toxic');
        }
        
        item.textContent = `⚠️ ${label.replace('_', ' ').toUpperCase()}: ${percentage}% confidence`;
        issuesList.appendChild(item);
    });
}

let ocrChart = null;

function createOCRChart(scores) {
    if (typeof Chart === 'undefined') {
        setTimeout(() => createOCRChart(scores), 100);
        return;
    }
    
    const chartCanvas = document.getElementById('ocr-chart-canvas');
    if (!chartCanvas) return;
    
    const ctx = chartCanvas.getContext('2d');
    
    // Destroy existing chart
    if (ocrChart) {
        ocrChart.destroy();
    }
    
    if (!scores || Object.keys(scores).length === 0) return;
    
    const labels = Object.keys(scores);
    const values = Object.values(scores);
    
    ocrChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels.map(l => l.replace('_', ' ').toUpperCase()),
            datasets: [{
                label: 'Toxicity Score',
                data: values,
                backgroundColor: values.map(v => {
                    if (v >= 0.6) return 'rgba(239, 68, 68, 0.8)';
                    if (v >= 0.3) return 'rgba(251, 191, 36, 0.8)';
                    return 'rgba(46, 204, 113, 0.8)';
                }),
                borderColor: values.map(v => {
                    if (v >= 0.6) return '#EF4444';
                    if (v >= 0.3) return '#F59E0B';
                    return '#2ECC71';
                }),
                borderWidth: 2,
                borderRadius: 8,
                borderSkipped: false,
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    backgroundColor: 'rgba(255, 255, 255, 0.95)',
                    titleColor: '#1A1A1A',
                    bodyColor: '#6B7280',
                    borderColor: '#E5E7EB',
                    borderWidth: 1,
                    padding: 12,
                    cornerRadius: 8,
                    callbacks: {
                        label: function(context) {
                            return `Score: ${(context.parsed.y * 100).toFixed(1)}%`;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 1,
                    ticks: {
                        color: '#6B7280',
                        font: { size: 12 },
                        callback: function(value) {
                            return (value * 100).toFixed(0) + '%';
                        }
                    },
                    grid: {
                        color: 'rgba(0, 0, 0, 0.05)'
                    }
                },
                x: {
                    ticks: {
                        color: '#1A1A1A',
                        font: { size: 11, weight: '600' }
                    },
                    grid: {
                        display: false
                    }
                }
            },
            animation: {
                duration: 1200,
                easing: 'easeOutQuart'
            }
        }
    });
}

function displayExtractedText(text) {
    const placeholder = document.querySelector('#ocr-results .results-placeholder');
    const resultsContent = document.getElementById('ocr-results-content');
    const extractedDisplay = document.getElementById('extracted-text-display');
    
    if (extractedDisplay) {
        extractedDisplay.textContent = text;
    }
    
    if (placeholder) placeholder.classList.add('hidden');
    if (resultsContent) resultsContent.classList.remove('hidden');
}

function copyExtractedText() {
    const extractedDisplay = document.getElementById('extracted-text-display');
    if (!extractedDisplay) return;
    
    const text = extractedDisplay.textContent;
    navigator.clipboard.writeText(text).then(() => {
        showToast('Text copied to clipboard!', 'success');
    }).catch(() => {
        showToast('Failed to copy text', 'error');
    });
}

function resetOCRResults() {
    const placeholder = document.querySelector('#ocr-results .results-placeholder');
    const resultsContent = document.getElementById('ocr-results-content');
    const toxicitySection = document.getElementById('ocr-toxicity-section');
    
    if (placeholder) placeholder.classList.remove('hidden');
    if (resultsContent) resultsContent.classList.add('hidden');
    if (toxicitySection) toxicitySection.classList.add('hidden');
    
    // Reset chart
    if (ocrChart) {
        ocrChart.destroy();
        ocrChart = null;
    }
}

// ============================================
// DASHBOARD
// ============================================

function setupDashboard() {
    const clearBtn = document.getElementById('clear-history-btn');
    if (clearBtn) {
        clearBtn.addEventListener('click', clearHistory);
    }
}

function loadHistory() {
    try {
        const stored = localStorage.getItem('toxicityAnalysisHistory');
        if (stored) {
            analysisHistory = JSON.parse(stored);
        }
    } catch (error) {
        console.error('Error loading history:', error);
        analysisHistory = [];
    }
}

function saveHistory() {
    try {
        localStorage.setItem('toxicityAnalysisHistory', JSON.stringify(analysisHistory));
    } catch (error) {
        console.error('Error saving history:', error);
    }
}

function addToHistory(text, data) {
    const entry = {
        id: Date.now(),
        text: text.substring(0, 100),
        fullText: text,
        timestamp: new Date().toISOString(),
        rating: data.rating || 'Unknown',
        severity: data.severity || 'low',
        scores: data.scores || {}
    };
    
    analysisHistory.unshift(entry);
    
    // Keep only last 50 entries
    if (analysisHistory.length > 50) {
        analysisHistory = analysisHistory.slice(0, 50);
    }
    
    console.log('[History] Added entry:', entry.text.substring(0, 50), 'Total entries:', analysisHistory.length);
    
    saveHistory();
    
    // Always try to update dashboard (it will only render if dashboard is active)
    updateDashboard();
}

function updateDashboard() {
    // Always update dashboard data, but only render if dashboard is active
    const safePercent = document.getElementById('safe-percent');
    const toxicPercent = document.getElementById('toxic-percent');
    const totalAnalyses = document.getElementById('total-analyses');
    const historyList = document.getElementById('history-list');
    
    // If dashboard view is not active, don't update DOM (but data is still saved)
    if (currentTool !== 'dashboard') {
        return;
    }
    
    console.log('[Dashboard] Updating dashboard with', analysisHistory.length, 'entries');
    
    if (!analysisHistory || analysisHistory.length === 0) {
        if (safePercent) safePercent.textContent = '0%';
        if (toxicPercent) toxicPercent.textContent = '0%';
        if (totalAnalyses) totalAnalyses.textContent = '0';
        if (historyList) {
            historyList.innerHTML = '<div class="history-empty"><p>No analysis history yet. Start analyzing to see results here.</p></div>';
        }
        return;
    }
    
    const total = analysisHistory.length;
    const safe = analysisHistory.filter(e => e.severity === 'low').length;
    const toxic = total - safe;
    
    const safePercentValue = Math.round((safe / total) * 100);
    const toxicPercentValue = Math.round((toxic / total) * 100);
    
    console.log('[Dashboard] Stats:', { total, safe, toxic, safePercentValue, toxicPercentValue });
    
    if (safePercent) safePercent.textContent = `${safePercentValue}%`;
    if (toxicPercent) toxicPercent.textContent = `${toxicPercentValue}%`;
    if (totalAnalyses) totalAnalyses.textContent = total;
    
    // Update history list
    if (historyList) {
        historyList.innerHTML = analysisHistory.map(entry => `
            <div class="history-item severity-${entry.severity || 'low'}">
                <div class="history-content">
                    <p class="history-text">${escapeHtml(entry.text)}${entry.text.length < entry.fullText.length ? '...' : ''}</p>
                    <div class="history-meta">
                        <span class="history-rating ${entry.severity || 'low'}">${entry.rating}</span>
                        <span class="history-time">${formatTime(entry.timestamp)}</span>
                    </div>
                </div>
            </div>
        `).join('');
    }
}

function clearHistory() {
    if (confirm('Are you sure you want to clear all analysis history?')) {
        analysisHistory = [];
        saveHistory();
        updateDashboard();
        showToast('History cleared', 'success');
    }
}

function formatTime(timestamp) {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now - date;
    
    if (diff < 60000) return 'Just now';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
    return date.toLocaleDateString();
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// ============================================
// UTILITY FUNCTIONS
// ============================================

function showLoading(text = 'Processing...') {
    const overlay = document.getElementById('loading-overlay');
    const loadingText = document.getElementById('loading-text');
    
    if (loadingText) loadingText.textContent = text;
    if (overlay) overlay.classList.remove('hidden');
}

function hideLoading() {
    const overlay = document.getElementById('loading-overlay');
    if (overlay) overlay.classList.add('hidden');
}

function showToast(message, type = 'info') {
    const toast = document.getElementById('toast');
    const toastIcon = toast.querySelector('.toast-icon');
    const toastMessage = toast.querySelector('.toast-message');
    const toastClose = toast.querySelector('.toast-close');
    
    if (!toast || !toastMessage) return;
    
    // Set icon based on type
    if (toastIcon) {
        const icons = {
            success: '✅',
            error: '❌',
            warning: '⚠️',
            info: 'ℹ️'
        };
        toastIcon.textContent = icons[type] || icons.info;
    }
    
    toastMessage.textContent = message;
    toast.classList.remove('hidden');
    
    // Auto-hide after 5 seconds
    setTimeout(() => {
        toast.classList.add('hidden');
    }, 5000);
    
    // Close button
    if (toastClose) {
        toastClose.onclick = () => toast.classList.add('hidden');
    }
}
